import Dashboard from "./components/Dashboard.jsx";

function App() {
    return <Dashboard />;
}

export default App;
